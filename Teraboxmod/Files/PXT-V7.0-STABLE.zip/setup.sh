#!/sbin/sh

###########################
# MMT Reborn Logic
###########################

############
# Config Vars
############

# Uncomment if you want to skip mount for your module
#SKIPMOUNT=true
# Uncomment if you want to clean old files in module before injecting new module
#CLEANSERVICE=true
# Uncomment if you want to load vskel after module info print. If you want to manually load it, consider using load_vksel function
AUTOVKSEL=false
# Uncomment DEBUG if you want store debug logs of installation
#DEBUG=true


############
# Replace List
############

# List all directories you want to directly replace in the system
# Construct your list in the following example format
REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"
# Construct your own list here
REPLACE="
"

############
# Cleanup
############

# Remove unnecessary stuff
do_cleanup() {
  rmtouch "$MODPATH/system/placeholder"
  rmtouch "$MODPATH/ARCH64.tar.xz"
  rmtouch "$MODPATH/ARCH32.tar.xz"
}


############
# Permissions
############

# Set permissions
set_permissions() {
  set_perm_recursive "$MODPATH" 0 0 0755 0644
}

############
# Info Print
############

# Set what you want to be displayed on header of installation process
info_print() {
 ui_print ""
  awk '{print}' "$MODPATH/PXT"
  ui_print ""
}

############
# Main
############

# Change the logic to whatever you want
int_main() {
ui_print ""
  ui_print " 📁 VERSION 7.0 "
sleep 1
ui_print ""
ui_print " 📲 Device Info "
ui_print ""
sleep 0.5
ui_print " 📲 DEVICE    🔹$(getprop ro.product.model) "
sleep 0.5
ui_print " 📲 BRAND     🔹$(getprop ro.product.system.brand) "
sleep 0.5
ui_print " 📲 MODEL     🔹$(getprop ro.build.product) "
sleep 0.5
ui_print " ⚙️ KERNEL    🔹$(uname -r) "
sleep 0.5
ui_print " ⚙️ PROCESSOR 🔹$(getprop ro.product.board) "
sleep 0.5
ui_print ""
ui_print " 🚫 Don't Use With Any Other Performance Related Module 🚫"
ui_print ""
sleep 2
[[ "$IS64BIT" == "true" ]] && tar -xf "$MODPATH/ARCH64.tar.xz" -C "$MODPATH" || tar -xf "$MODPATH/ARCH32.tar.xz" -C "$MODPATH"
 
 ####
 
# tar -xf "$MODPATH/termux.tar.xz" -C "$MODPATH/data/data/com.termux/files/usr/libexec/"

# Load Vol Key Selector

# Load Vol Key Selector
# $TMPDIR/addon/Volume-Key-Selector/install.sh
#load_vksel
ui_print ""
ui_print " [~] INSTALLING ------- "
ui_print ""
sleep 2.0
ui_print " [√] DONE "
ui_print ""
ui_print " 🖥️ TERMUX COMMAND su -c pxt"

set_permissions() {
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm_recursive "$MODPATH/system" 0 0 0755 0644
set_perm_recursive "$MODPATH/system/xbin" 0 0 0755 0644
set_perm_recursive "$MODPATH/system/bin" 0 0 0755 0755
}
}
